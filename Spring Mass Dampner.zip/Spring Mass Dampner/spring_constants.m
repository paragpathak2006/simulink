k = 3800;
m = 10;
b= 10;
% G1 = 50*1e3;    c1 = 0.9;       mu1 = 1;                                
% G2 = 500*1e3;   c2 = 0.1;       mu2 = 10;    
% 
% mu0 = 1.25663706 * 1e-6;        L0 = 0.01;
% Gbar = G1*c1 + G2*c2;           mubar = mu0*(mu1*c1 + mu2*c2);   
% Gcap = 1/(c1/G1 + c2/G2);       mucap = mu0/(c1/mu1 + c2/mu2);
% (1-mucap/mubar)